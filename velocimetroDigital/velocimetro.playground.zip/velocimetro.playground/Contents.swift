//: Velocímetro de un automóvil

import UIKit

enum Velocidades : Int {case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120

init (velocidadInicial : Velocidades) {
        
        self = velocidadInicial
    
    }}
    



class Auto {
    
    var velocidad : Velocidades
    
    init(){
        
        velocidad = .Apagado
        
    }
    
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena : String){
        
        var actual : Int = velocidad.rawValue
        
        var velocidadEnCadena : String = ""
        
        switch actual {
            
        case Velocidades.Apagado.rawValue :
            
            velocidad = .VelocidadBaja
            velocidadEnCadena = "Velocidad baja"
            
        case Velocidades.VelocidadBaja.rawValue :
            
            velocidad = .VelocidadMedia
            velocidadEnCadena = "Velocidad media"
            
        case Velocidades.VelocidadMedia.rawValue :
            
            velocidad = .VelocidadAlta
            velocidadEnCadena = "Velocidad alta"
            
        case Velocidades.VelocidadAlta.rawValue :
            
            velocidad = .VelocidadMedia
            velocidadEnCadena = "Velocidad media"
            
        default :
            
            velocidad = .Apagado
            velocidadEnCadena = "Apagado"
            
        }
        
        actual = velocidad.rawValue
        return (actual, velocidadEnCadena)
        
    }
    
    }


var auto = Auto()

var actual : Int = 0
var velocidadEnCadena : String = ""

for i in 1...20 {
    
    (actual: actual, velocidadEnCadena : velocidadEnCadena) =
    
    auto.cambioDeVelocidad()
    print("\(i). \(actual), \(velocidadEnCadena)")
    
}
    


